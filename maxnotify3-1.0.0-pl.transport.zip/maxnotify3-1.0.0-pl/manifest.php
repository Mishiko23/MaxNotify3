<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => array (
    'name' => 'MaxNotify 3',
    'author' => 'Mishiko23',
    'email' => 'bigo2008@gmail.com',
    'description' => '**MaxNotify 3** — отдельный компонент для MODX Revolution 3 и miniShop3,
который отправляет уведомления о заказах в мессенджер MAX через
<a href="https://dev.max.ru/docs/maxbusiness/connection">официальный MAX Business API</a>
или через сервис (<a href="https://rumaxbot.ru">https://rumaxbot.ru</a>).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

Разработчик: Mishiko23  
Email: bigo2008@gmail.com',
    'license' => 'MIT License

Copyright (c) 2026 Mishiko23 <bigo2008@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# MaxNotify 3 для miniShop3

**MaxNotify 3** — отдельный компонент для MODX Revolution 3 и miniShop3,
который отправляет уведомления о заказах в мессенджер MAX через
<a href="https://dev.max.ru/docs/maxbusiness/connection">официальный MAX Business API</a>
или через сервис (<a href="https://rumaxbot.ru">https://rumaxbot.ru</a>).

Компонент помогает владельцу и менеджерам интернет-магазина быстро узнавать
о новых заказах и изменениях их статуса без постоянной проверки панели MODX.

## Автор

Разработчик: Mishiko23  
Email: bigo2008@gmail.com

## Возможности

- уведомление сразу после создания заказа miniShop3;
- уведомление при изменении статуса заказа;
- фильтрация уведомлений по ID статусов;
- номер, сумма и состав заказа;
- имя, телефон и email покупателя;
- адрес доставки и комментарий клиента;
- название способа доставки и оплаты;
- ссылка на конкретный заказ в панели MODX;
- официальный MAX Business API и сервис rumaxbot.ru на выбор;
- отправка одному или нескольким чатам, каналам или пользователям;
- сообщения в формате Markdown или HTML;
- редактируемые чанки сообщений;
- запись ошибок API и соединения в журнал MODX.

## Требования

- MODX Revolution 3.x;
- miniShop3 1.x;
- PHP 8.1+;
- PHP cURL или включённый `allow_url_fopen`;
- токен официального MAX-бота или канал и API-ключ rumaxbot.ru;
- для MAX Business API: доступ к `https://platform-api2.max.ru/messages` и
  сертификат Минцифры, добавленный в доверенные на сервере.

Компонент проверен с MODX Revolution 3.2.1-pl и miniShop3 1.11.1-beta1.

## Установка

1. Откройте в MODX раздел **Пакеты → Установщик**.
2. Найдите компонент MaxNotify 3 в репозитории.
3. Нажмите **Скачать**, затем **Установить**.
4. После установки очистите кэш MODX.

## Настройка

Откройте **Системные настройки** и выберите пространство имён `maxnotify3`.

Основные параметры:

- <strong>maxnotify3.enabled</strong> — включает или отключает компонент;
- <strong>maxnotify3.provider</strong> — `rumaxbot` или `maxbusiness`;
- <strong>maxnotify3.format</strong> — `markdown` или `html`;
- <strong>maxnotify3.timeout</strong> — таймаут API-запроса в секундах;
- <strong>maxnotify3.notify_new_order</strong> — уведомления о новых заказах;
- <strong>maxnotify3.notify_status_change</strong> — уведомления о смене статуса;
- <strong>maxnotify3.statuses</strong> — ID статусов через запятую, пустое поле разрешает все.

## Подключение официального MAX Business API

С 19 июля 2026 для корректной работы чат-ботов и мини-приложений MAX требуется
использовать адрес `platform-api2.max.ru` вместо `platform-api.max.ru`.
MaxNotify 3 по умолчанию отправляет запросы на
`https://platform-api2.max.ru/messages`.

Также на сервере, где установлен MODX, сертификат Минцифры должен быть добавлен
в доверенное хранилище ОС/PHP/cURL. Это системная настройка сервера, а не
настройка компонента.

Официальное подключение доступно верифицированным организациям и ИП, которые
являются резидентами РФ.

Создайте и верифицируйте профиль на
<a href="https://business.max.ru/">платформе MAX для партнёров</a>.
Создайте чат-бота и дождитесь прохождения модерации.
Получите токен в разделе <strong>Чат-боты → Перейти → Расширенные настройки → Настроить</strong>.
Добавьте бота в нужный чат или канал либо запустите личный диалог с ботом.
Получите <strong>chat_id</strong> или <strong>user_id</strong> через
<strong>Webhook/Long Polling API MAX</strong>.
Установите `maxnotify3.provider` в значение `maxbusiness`.

Заполните настройки:

- <strong>maxnotify3.max_token</strong> — токен бота;
- <strong>maxnotify3.max_api_url</strong> — endpoint отправки сообщений MAX,
  по умолчанию `https://platform-api2.max.ru/messages`;
- <strong>maxnotify3.max_recipient_type</strong> — <strong>chat_id</strong> или <strong>user_id</strong>;
- <strong>maxnotify3.max_recipient_ids</strong> — один или несколько ID через запятую;
- <strong>maxnotify3.max_notify</strong> — уведомлять участников чата;
- <strong>maxnotify3.max_disable_link_preview</strong> — отключить превью ссылок.

Официальный API принимает сообщения длиной до 4000 символов. Более длинные
уведомления MaxNotify 3 автоматически сокращает.

## Подключение rumaxbot.ru

1. Зарегистрируйтесь на rumaxbot.ru и подтвердите email.
2. Создайте канал.
3. Подключите MAX-бота к каналу по инструкции сервиса.
4. Создайте API-ключ канала.
5. Укажите ключ в настройке `maxnotify3.api_key`.

API-ключ нельзя публиковать или добавлять в репозиторий.

## Шаблоны сообщений

После установки в категории элементов `MaxNotify 3` будут созданы чанки:

- `maxNotify3OrderCreated` — новый заказ в Markdown;
- `maxNotify3OrderStatus` — новый статус в Markdown;
- `maxNotify3OrderCreatedHtml` — новый заказ в HTML;
- `maxNotify3OrderStatusHtml` — новый статус в HTML.

Доступные плейсхолдеры: `num`, `uuid`, `cost`, `receiver`, `first_name`,
`last_name`, `phone`, `email`, `address`, `comment`, `order_comment`,
`products`, `delivery_name`, `payment_name`, `status_name`, `manager_url` и
другие поля заказа miniShop3.
',
    'changelog' => '# История изменений MaxNotify 3

## 1.0.0-pl

- создан отдельный пакет `maxnotify3` для MODX Revolution 3 и miniShop3;
- добавлена поддержка namespaced-моделей miniShop3;
- обновлены поля заказа: `status_id`, `delivery_id`, `payment_id`;
- обновлена ссылка на заказ в менеджере MODX: `namespace=minishop3`;
- добавлены отдельные настройки, чанки и plugin `MaxNotify 3`;
- обновлён endpoint MAX Business API по умолчанию на `https://platform-api2.max.ru/messages`;
- добавлена документация о необходимости доверенного сертификата Минцифры для MAX Business API;
- сохранены провайдеры MAX Business API и rumaxbot.ru.
',
  ),
  'manifest-vehicles' => array (
    0 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '5a50086f2886ff3d8e5498fbf9893acd',
      'native_key' => 'maxnotify3',
      'filename' => 'MODX/Revolution/modNamespace/414beecdccdd1c01ad97c9b974d60ae0.vehicle',
      'namespace' => 'maxnotify3',
    ),
    1 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '3dbc8ddfc833f138205b168fe951e43e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/d12f171c49de53db2c95a8861bb5d448.vehicle',
      'namespace' => 'maxnotify3',
    ),
    2 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f6250ed269ed0ad5131d1c96e32f42ee',
      'native_key' => 'maxnotify3.enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/b4cb6662a6ec033ba6bf426946f05cae.vehicle',
      'namespace' => 'maxnotify3',
    ),
    3 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '45315ff4c57696c930993d083cd3170f',
      'native_key' => 'maxnotify3.provider',
      'filename' => 'MODX/Revolution/modSystemSetting/033a5c5cfa0607faf176a81552666f2f.vehicle',
      'namespace' => 'maxnotify3',
    ),
    4 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e97a1fc9d202e4ef2a43331a066819f3',
      'native_key' => 'maxnotify3.api_url',
      'filename' => 'MODX/Revolution/modSystemSetting/c6172ebe2761eac4e5a017debc1f5200.vehicle',
      'namespace' => 'maxnotify3',
    ),
    5 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2027d8999053333276f7a3c54747d268',
      'native_key' => 'maxnotify3.api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/8b7d55299ddfe7fe039c8d3eaf4f4a79.vehicle',
      'namespace' => 'maxnotify3',
    ),
    6 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '163d1404d3f2270356be4d27340783c4',
      'native_key' => 'maxnotify3.max_api_url',
      'filename' => 'MODX/Revolution/modSystemSetting/25c060c6f1638acbe09bc9528720a184.vehicle',
      'namespace' => 'maxnotify3',
    ),
    7 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da34d454592d023885b1f6480b754cc9',
      'native_key' => 'maxnotify3.max_token',
      'filename' => 'MODX/Revolution/modSystemSetting/5f1ff0c255d1c2d6ea5618a20546aba9.vehicle',
      'namespace' => 'maxnotify3',
    ),
    8 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd920cd18a397efd66a5ab4922125c4e1',
      'native_key' => 'maxnotify3.max_recipient_type',
      'filename' => 'MODX/Revolution/modSystemSetting/851be08fbe6640231c65989961dec564.vehicle',
      'namespace' => 'maxnotify3',
    ),
    9 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6655ae7d5ea84856286b109be2a01d2d',
      'native_key' => 'maxnotify3.max_recipient_ids',
      'filename' => 'MODX/Revolution/modSystemSetting/915310a9e9d6ccabe129f562c00b622c.vehicle',
      'namespace' => 'maxnotify3',
    ),
    10 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'df7b3f26f9e6ca751fb72c915b6b906e',
      'native_key' => 'maxnotify3.max_notify',
      'filename' => 'MODX/Revolution/modSystemSetting/de5cffed68508c837b316adca7bf43b8.vehicle',
      'namespace' => 'maxnotify3',
    ),
    11 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '192b4084d9abb4de8f2e7c6a058dcd5d',
      'native_key' => 'maxnotify3.max_disable_link_preview',
      'filename' => 'MODX/Revolution/modSystemSetting/bd51c59aee9145bf5429294ff367b10b.vehicle',
      'namespace' => 'maxnotify3',
    ),
    12 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac2fb1a9ca414efe0e8d1f18107a39af',
      'native_key' => 'maxnotify3.format',
      'filename' => 'MODX/Revolution/modSystemSetting/1d3357f37124759f9bbfc2f69aeeca8b.vehicle',
      'namespace' => 'maxnotify3',
    ),
    13 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '92a9a75c02ece3678e317d1d94493857',
      'native_key' => 'maxnotify3.timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/e6d5d29f38de6f64b9614d42702a3bd1.vehicle',
      'namespace' => 'maxnotify3',
    ),
    14 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6102bebbf86a115c08524575ab586304',
      'native_key' => 'maxnotify3.notify_new_order',
      'filename' => 'MODX/Revolution/modSystemSetting/2f983b05e5c4e023f2ae7c7a01b92f88.vehicle',
      'namespace' => 'maxnotify3',
    ),
    15 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '17872f2a9f59f2bee0d81bcf02b9b347',
      'native_key' => 'maxnotify3.notify_status_change',
      'filename' => 'MODX/Revolution/modSystemSetting/eadf9cd618fe8fde854806d54abc1d1b.vehicle',
      'namespace' => 'maxnotify3',
    ),
    16 => array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '937526b20e10edf0f7c28d16ddfa76c8',
      'native_key' => 'maxnotify3.statuses',
      'filename' => 'MODX/Revolution/modSystemSetting/80078bc1a62bb87a991971c0a976c4c6.vehicle',
      'namespace' => 'maxnotify3',
    ),
  ),
);
